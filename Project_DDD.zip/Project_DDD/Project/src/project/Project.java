package project;

import java.text.SimpleDateFormat;

import java.util.ArrayList;
import java.util.Date;

public class Project {
    String Name;
    Date EndDate;
    String ClientId;
    String Status;
    String Reference;
    String ProjectManagerId;
    ArrayList<ArrayList<String>> SpecialistId=  
               new ArrayList<ArrayList<String>>(2);
    private Project(){
        
    }
    private Project(String name, Date endDate, String clientId) {
        Name = name;
        EndDate = endDate;
        ClientId = clientId;
        Status = "Draft";
        Reference = ReferenceValue.getReference();
    }
    public void addSpecialist(String specialistId) throws Exception {
        boolean recFound = false;
        if(Status!="Active"){
            throw new Exception("Active Project not found");
        }
        for (int i = 0; i <SpecialistId.size(); i++) { 
            if(SpecialistId.get(i).get(0)==specialistId){
                       recFound = true;
                       break;
                } 
        }
        if(recFound == true){
            throw new Exception("SpecialistId '"+specialistId+"' already present");
        }
        ArrayList<String> newList = new ArrayList<String>();
        newList.add(specialistId);
        newList.add("Pending");
        SpecialistId.add(newList);
    }
    public void approveSpecialist(String specialistId) throws Exception {
        boolean recFound = false;
        if(Status!="Active"){
            throw new Exception("Active Project not found");
        }
        for (int i = 0; i <SpecialistId.size(); i++) { 
            if(SpecialistId.get(i).get(0)==specialistId){
                       recFound = true;
                       SpecialistId.get(i).set(1,"Approved");
                       break;
                } 
        }
        if(recFound == false){
            throw new Exception("Pending SpecialistId '"+specialistId+"' not found");
   
        }
    }
    public void rejectSpecialist(String specialistId) throws Exception {
        boolean recFound = false;
        if(Status!="Active"){
            throw new Exception("Active Project not found");
        }
        for (int i = 0; i <SpecialistId.size(); i++) { 
            if(SpecialistId.get(i).get(0)==specialistId){
                       recFound = true;
                       SpecialistId.get(i).set(1,"Rejected");
                       break;
                } 
        }
        if(recFound == false){
            throw new Exception("Pending SpecialistId '"+specialistId+"' not found");
    
        }
    }
    public Project Draft(String name,Date endDate, String clientId) {
        return new Project(name,endDate,clientId);
    }
    public void Start(String strProjectManagerId) throws Exception {
        if(Status!="Draft"){
            throw new Exception("Draft Project not found");
        }
        Status = "Active";
        ProjectManagerId = strProjectManagerId;
            
    }
    public static void main(String[] args) throws Exception {
        try {
            String name = "Test";
            Date endDate = new SimpleDateFormat("dd/MM/yyyy").parse("31/12/2020");
            String clientId = "FIS";
            String ProjectManagerId = "MALAKE957";
            //Project project = new Project(name,endDate,clientId);
            Project project = new Project();
            project = project.Draft(name,endDate,clientId);
            project.Start(ProjectManagerId);
            project.addSpecialist("abc1");
            project.addSpecialist("abc2");
            project.addSpecialist("abc3");
            project.addSpecialist("abc4");
            project.approveSpecialist("abc1");
            project.approveSpecialist("abc3");
            project.rejectSpecialist("abc4");
            System.out.println("Project Name:"+project.Name);
            System.out.println("Project End Date:"+project.EndDate);
            System.out.println("Project Client Id:"+project.ClientId);
            System.out.println("Project Manager Id:"+project.ProjectManagerId);
            System.out.println("Project Reference:"+project.Reference);
            for (int i = 0; i <project.SpecialistId.size(); i++) { 
                    System.out.println(project.SpecialistId.get(i).get(0) + "-" + project.SpecialistId.get(i).get(1));
                    
            }
        }
        catch(Exception e){
            System.out.println(e.toString());
        }
    }
    
}