package project;

public class ReferenceValue {
    private static final String PREFIX = "FIS";
    private static int number = 1000;

    public static String getReference() {
        return PREFIX + number++;
    }
}